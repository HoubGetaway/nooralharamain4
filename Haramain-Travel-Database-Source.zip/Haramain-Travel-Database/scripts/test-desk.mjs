import fs from 'node:fs';
import {transform} from 'esbuild';
import {DatabaseSync} from 'node:sqlite';
import assert from 'node:assert/strict';
const source=fs.readFileSync('app/api/desk/route.ts','utf8').replace("import {env} from 'cloudflare:workers';",'const env=globalThis.deskTestEnv;');
const sql=new DatabaseSync(':memory:');for(const file of fs.readdirSync('drizzle').filter(s=>s.endsWith('.sql')).sort())sql.exec(fs.readFileSync('drizzle/'+file,'utf8'));
const files=new Map();
globalThis.deskTestEnv={DB:{prepare(query){const stmt=sql.prepare(query);let values=[];return {bind(...v){values=v;return this},async first(){return stmt.get(...values)||null},async all(){return {results:stmt.all(...values)}},async run(){return stmt.run(...values)}}}},BUCKET:{async put(key,bytes,meta){files.set(key,{body:bytes,httpMetadata:meta.httpMetadata})},async get(key){return files.get(key)||null}}};
const code=(await transform(source,{loader:'ts',format:'esm'})).code;
const {GET,POST}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
async function call(body,cookie='',query=''){const multipart=body instanceof FormData;const request=new Request('https://desk.test/api/desk'+query,{method:body?'POST':'GET',headers:{cookie,...(multipart?{}:{'Content-Type':'application/json'})},...(body?{body:multipart?body:JSON.stringify(body)}:{})});const response=await(body?POST(request):GET(request));const json=response.headers.get('Content-Type')?.includes('application/json');return {status:response.status,data:json?await response.json():await response.arrayBuffer(),cookie:response.headers.getSetCookie().map(v=>v.split(';')[0]).join('; ')}}
const guest=await call(),other=await call();assert(guest.data.user.guest);assert.notEqual(guest.cookie,other.cookie);
const password=crypto.randomUUID();const admin=await call({action:'setup',name:'Admin',username:'test-owner',password},guest.cookie);assert.equal(admin.status,200);const ac=admin.cookie;
assert.equal((await call({action:'user',name:'Second admin',username:'second',password,role:'Admin'},ac)).status,400);
assert.equal((await call({action:'user',name:'Staff',username:'test-staff',password,role:'Staff'},ac)).status,200);
assert.equal((await call({action:'user',name:'Viewer',username:'test-viewer',password,role:'Viewer'},ac)).status,200);
const staff=await call({action:'login',username:'test-staff',password},other.cookie),viewer=await call({action:'login',username:'test-viewer',password},other.cookie);
assert.equal((await call({action:'user',name:'Forbidden',username:'forbidden',password,role:'Staff'},staff.cookie)).status,403);
assert.equal((await call({action:'save',kind:'Settings',data:{primaryColor:'#245c88'}},staff.cookie)).status,403);
assert.equal((await call({action:'save',kind:'Settings',data:{primaryColor:'invalid'}},ac)).status,400);
assert.equal((await call({action:'save',kind:'Settings',data:{primaryColor:'#245c88',accentColor:'#d3a963',backgroundColor:'#f2f6fa'}},ac)).status,200);
assert.equal((await call({action:'save',kind:'Employees',data:{name:'Test employee',salary:300}},ac)).status,200);
let records=(await call(undefined,ac)).data.records;const employee=records.find(r=>r.kind==='Employees');
const attendance={action:'save',kind:'Attendance',data:{employee:employee.id,date:'2026-11-12',status:'Present'}};
assert.equal((await call(attendance,staff.cookie)).status,200);assert.equal((await call(attendance,staff.cookie)).status,400);
assert.equal((await call({...attendance,data:{...attendance.data,date:'2026-11-13'}},viewer.cookie)).status,403);
assert.equal((await call({...attendance,data:{...attendance.data,date:'2026-11-13'}},other.cookie)).status,400);
const png=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aS1sAAAAASUVORK5CYII=','base64');
function photo(file=new File([png],'logo.png',{type:'image/png'})){const form=new FormData();form.append('slot','logo');form.append('photo',file);return form}
const upload=await call(photo(),ac);assert.equal(upload.status,200);assert.equal((await call(undefined,ac,'?asset=logo')).status,200);assert.equal((await call(undefined,other.cookie,'?asset=logo')).status,404);assert.equal((await call(photo(),staff.cookie)).status,403);assert.equal((await call(photo(new File(['invalid'],'bad.png',{type:'image/png'})),ac)).status,400);
const all=(await call(undefined,ac)).data;const staffUser=all.users.find(u=>u.username==='test-staff');const newPassword=crypto.randomUUID();assert.equal((await call({action:'user',id:staffUser.id,password:newPassword},ac)).status,200);assert.equal((await call(undefined,staff.cookie)).data.user,undefined);assert.equal((await call({action:'login',username:'test-staff',password:newPassword},other.cookie)).status,200);
assert.equal((await call({action:'user',id:all.user.id,active:false},ac)).status,400);assert.equal(all.users.filter(u=>u.role==='Admin').length,1);

// Account categories preserve legacy main accounts and enforce linked-party/currency boundaries.
assert.equal((await call({action:'save',kind:'Agents',data:{name:'Account agent'}},ac)).status,200);
assert.equal((await call({action:'save',kind:'Suppliers',data:{name:'Account supplier'}},ac)).status,200);
const parties=(await call(undefined,ac)).data.records;const agent=parties.find(r=>r.kind==='Agents'),supplier=parties.find(r=>r.kind==='Suppliers');
for(const category of ['Main accounts','Agency agent accounts','Leader agent accounts','Supplier accounts']){
 const holder=category==='Main accounts'?'':category==='Supplier accounts'?supplier.id:agent.id;
 assert.equal((await call({action:'save',kind:'Accounts',data:{name:category,category,currency:'USD',amount:100,type:'Cash',holder}},ac)).status,200);
}
assert.equal((await call({action:'save',kind:'Accounts',data:{name:'Unlinked',category:'Supplier accounts',currency:'USD',amount:0,holder:agent.id}},ac)).status,400);
const account=(await call(undefined,ac)).data.records.find(r=>r.kind==='Accounts'&&r.category==='Main accounts');
assert.equal((await call({action:'save',kind:'Transactions',data:{name:'Receipt',account:account.id,currency:'USD',amount:25,direction:'Income'}},ac)).status,200);
assert.equal((await call({action:'save',kind:'Expenses',data:{name:'Mismatch',account:account.id,currency:'SAR',amount:5}},ac)).status,400);
assert.equal((await call({action:'save',kind:'Accounts',id:account.id,data:{...account,currency:'AFN'}},ac)).status,400);
assert.equal((await call({action:'save',kind:'Accounts',data:{name:'Legacy style',currency:'USD',amount:0,type:'Bank'}},ac)).status,200);
assert.equal((await call(undefined,ac)).data.records.find(r=>r.name==='Legacy style').category,'Main accounts');
console.log('PASS: all four account sections, holder validation, account currency matching, posted-account currency protection and legacy main-account defaults.');
console.log('PASS: single admin, staff account permissions, password reset/session revocation, theme validation, employee attendance uniqueness, role checks, image upload validation and workspace isolation.');
