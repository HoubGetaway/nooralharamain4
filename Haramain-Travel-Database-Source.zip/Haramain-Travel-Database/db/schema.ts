import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const records=sqliteTable('records',{id:text('id').primaryKey(),workspace:text('workspace').notNull().default('legacy'),kind:text('kind').notNull(),data:text('data').notNull(),updated:text('updated').notNull()});
export const users=sqliteTable('users',{id:text('id').primaryKey(),workspace:text('workspace').notNull().default('legacy'),username:text('username').notNull().unique(),name:text('name').notNull(),hash:text('hash').notNull(),salt:text('salt').notNull(),role:text('role').notNull(),active:integer('active').notNull().default(1)});
export const sessions=sqliteTable('sessions',{id:text('id').primaryKey(),userId:text('user_id').notNull(),last:integer('last').notNull()});
