# Haramain Travel Database — standalone source

This folder contains the complete editable source for the travel agency app. It is configured to publish to **your own Cloudflare Workers account**, using **D1** for records and **R2** for uploaded images. No ChatGPT account or original hosting project is required to run this copy.

This is a server-backed React / TypeScript application. Uploading the files to a static HTML host, GitHub Pages, or an ordinary cPanel public_html folder will not run the database or login API. Other hosting providers require a backend/storage adapter; none is included in this package.

## Included features

- Dashboard, customers, ticket examples, tickets and shared holds.
- Visa / Umrah bookings; mutamers, groups and group tickets.
- Finance accounts, transactions, expenses and reports; separate USD / AFN / SAR totals.
- Four account sections: Main, Agency agent, Leader agent and Supplier accounts, each with linked holders, balances and account ledgers. Existing uncategorized accounts appear under Main accounts.
- Partners, agents, suppliers, visa applications and employees.
- Employee attendance, monthly present/absent/leave/half-day totals, and salary fields.
- Booking, income/outgoing and booking-status charts.
- One main administrator per workspace; staff / viewer logins, account disabling, password resets and auto logout.
- Original Noorul Haramain logo included as the main brand, with its blue, turquoise and green palette.
- Dimensional cards, layered shadows, floating logo display and reduced-motion support.
- Logo / cover-image uploads, color palettes, custom colors and dashboard text.
- CSV exports, printable views and JSON record exports.

## 1. Install

Install **Node.js 24 or newer** and open a terminal inside this extracted folder. On Windows, open the folder, right-click and choose **Open in Terminal**.

```sh
npm ci
npm run typecheck
npm test
```

`node_modules` is intentionally excluded from the download. `npm ci` installs the exact dependencies in `package-lock.json`. The app uses Vinext 1.0.0-beta.5 and Cloudflare's Vite plugin; versions are pinned in the lockfile.

## 2. Try it locally

```sh
npm run db:local
npm run dev
```

Open the localhost URL printed in the terminal. D1 and R2 are emulated on your computer for local development. The all-zero database ID in `wrangler.jsonc` is a local placeholder, not a real cloud database.

The first visit opens a dashboard without a password. This browser receives a random, HTTP-only workspace cookie and sees only its own workspace records. Do not clear that cookie until you create a login if you need to retain access.

To create your main administrator, open **Settings → Enable login**. Choose your own name, unique username and password of at least 10 characters. Existing workspace records stay in place. After login is enabled, that workspace requires its login.

Use **Settings → Add user** for Staff or Viewer accounts. Share your deployed website address and each user's credentials through your usual private channel. On another browser/device, select **Staff sign in** to access the same workspace. Without signing in, a different browser opens a separate empty workspace.

Local and production storage are separate. Creating an administrator locally does not create that account on the deployed website.

## 3. Create your Cloudflare resources

Sign in to your own account:

```sh
npx wrangler login
npx wrangler d1 create travel-desk-db
npx wrangler r2 bucket create travel-desk-photos
```

Open **wrangler.jsonc**:

1. Replace `database_id` with the D1 database ID returned by the create command.
2. Keep `binding` as **DB** and **BUCKET**; the application expects these names.
3. If you chose a different database or bucket name, update `database_name` / `bucket_name`.
4. Optionally change the Worker `name` to a unique project name.

The database ID is configuration, not a password. Keep Cloudflare API tokens outside source control. This application needs no application secret or ChatGPT credentials to deploy.

## 4. Initialize the online database and publish

```sh
npm run db:remote
npm run build
npm run deploy
```

- `db:remote` applies the included schema migrations to your D1 database.
- `build` creates the Worker and browser assets under `dist/`.
- `deploy` uploads the generated Worker and assets using `dist/server/wrangler.json`.

Open the Workers URL printed after deployment. Create your **production administrator** in Settings, then create staff logins and upload your logo / cover photo. Workers & Pages in your Cloudflare dashboard lets you attach a domain you own.

For later code updates, run checks and tests, apply any new migrations, rebuild and deploy. Never replace an already-applied migration with edited SQL; add a new migration when changing the schema.

## 5. Where to edit

| File / folder | Purpose |
| --- | --- |
| `app/desk.tsx` | Dashboard, navigation, forms and user settings |
| `app/appearance.tsx` | Logo / cover uploads, palettes and appearance controls |
| `app/insights.tsx` | Charts and attendance summaries |
| `app/globals.css` | Responsive visual styling and print styles |
| `app/api/desk/route.ts` | Server API, login, permissions, records and image storage |
| `db/schema.ts` | Database schema declarations |
| `drizzle/` | SQL migrations and schema history |
| `worker/index.ts` | Cloudflare Worker entry point |
| `vite.config.ts` | Standalone build configuration |
| `wrangler.jsonc` | Your Worker, D1 and R2 deployment configuration |
| `scripts/test-desk.mjs` | API security, attendance and upload tests |

## Data and behavior notes

This download contains source code and schema migrations. It does **not** contain live customers, passport data, usernames, password hashes, user-uploaded photos (apart from the included brand logo), sessions, cloud credentials or the original site's project identity. The new deployment starts with an empty database.

The current Settings export produces JSON records for your archive. This version does not include an import/restore screen, so that JSON is not a one-click migration to this new deployment. For a complete account-level migration, database and R2 storage need a separate authorized export/import.

Booking values and paid amounts describe sales and receivables. Record actual receipts/payments in Transactions and each expense once in Expenses. Attendance totals do not automatically deduct salaries. The app saves online; it does not include offline synchronization.

If sign-in or saving fails locally, run `npm run db:local` and ensure the browser allows cookies. If production reports the database unavailable, verify your D1 binding and run `npm run db:remote`. If photo uploads fail, verify the R2 bucket and BUCKET binding. JPG, PNG and WebP uploads are limited to 3 MB.

## Verification

The export was checked with TypeScript, the included API tests, and a standalone production build. No deployment to your own Cloudflare account is performed by downloading this folder.
