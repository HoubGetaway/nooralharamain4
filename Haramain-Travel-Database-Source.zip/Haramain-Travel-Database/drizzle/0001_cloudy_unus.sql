ALTER TABLE `records` ADD `workspace` text DEFAULT 'legacy' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `workspace` text DEFAULT 'legacy' NOT NULL;