export const BRAND={name:'Noorul Haramain',logo:'/noorul-haramain-logo.jpeg',primary:'#006faf',accent:'#009d8c',background:'#f0f7fc',version:'noorul-v2'};
export function brandSettings(raw:Record<string,any>){return raw.brandVersion===BRAND.version?raw:{...raw,brandVersion:BRAND.version,primaryColor:BRAND.primary,accentColor:BRAND.accent,backgroundColor:BRAND.background,logoUrl:BRAND.logo};}
