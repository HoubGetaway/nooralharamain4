import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'Noorul Haramain • Travel & Tours',description:'Noorul Haramain Travel & Tours — bookings, Umrah operations and finance.',icons:{icon:'/noorul-haramain-logo.jpeg'}};
export default function Layout({children}:Readonly<{children:React.ReactNode}>){return <html lang="en"><body>{children}</body></html>}
